
INTERPRETAR LOS RESULTADOS OBTENIDOS DE LOS FICHEROS Resultado1.txt Y Resultado2.txt
------------------------------------------------------------------------------------

Hemos puesto las instáncias en el orden obtenido al usar la función sort.
Por favor, tened en cuenta esto a la hora de hacer el diff para comprovar 
que nuestras soluciones son correctas.
